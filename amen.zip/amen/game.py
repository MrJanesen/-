import pygame
import pygame.locals as locals
import random



class Man(object):
    speed = 0
    def __init__(self):
        self.img = pygame.image.load("./picture/peiqi.png")
        self.width = self.img.get_width()
        self.height = self.img.get_height()
        self.x = SCREEN_SIZE[0] / 2 - self.width / 2
        self.y = self.height / 2
        self.max_speed = 5

    def update(self):
        if self.speed < self.max_speed:
            self.speed += 1
        self.y += self.speed
        surface.blit(self.img, (self.x, self.y))

    def left_move(self):
        self.x -= self.width / 2

    def right_move(self):
        self.x += self.width / 2

    def is_dead(self):
        if self.y <= 0 or self.y > (SCREEN_SIZE[1] - self.height):
            return True
        return False

    def contact(self):
        for platform in platformlist:
            if self.x + self.width / 4 * 3 > platform.x and self.x + self.width / 4 < platform.x + platform.WIDTH:
                if self.y + self.height >= platform.y and self.y + self.height <= platform.y + platform.HEIGHT:
                    return True
        return False


class Platform(object):
    img = pygame.image.load("./picture/platform.png")
    WIDTH = img.get_width()
    HEIGHT = img.get_height()

    def __init__(self):
        self.y = SCREEN_SIZE[1]
        self.speed = 5
        self.x = random.randint(0, SCREEN_SIZE[0] - Platform.WIDTH)

    def update(self):
        self.y -= self.speed
        surface.blit(Platform.img, (self.x, self.y))

    def need_remove(self):
        if self.y == 0:
            return True
        return False


def init():
    global surface, clock, man, platformlist
    surface = pygame.display.set_mode(SCREEN_SIZE)
    clock = pygame.time.Clock()
    man = Man()
    platformlist = []
    platformlist.append(Platform())


def create_platform():
    if count % 40 == 0:
        platformlist.append(Platform())


def update_platform():
    create_platform()
    i = len(platformlist) - 1
    while i >= 0:
        if not platformlist[i].need_remove():
            platformlist[i].update()
        else:
            del platformlist[i]
        i -= 1


def controller():
    for event in pygame.event.get():
        if event.type == locals.QUIT:
            exit()
        if event.type == locals.KEYDOWN:
            if event.key == locals.K_LEFT:
                man.left_move()
            elif event.key == locals.K_RIGHT:
                man.right_move()


pygame.init()
FPS = 50
SCREEN_SIZE = (350, 480)

if __name__ == '__main__':
    init()
    while True:
        init()
        count = 0

        while True:
            count += 1
            controller()
            surface.fill((152, 199, 252))
            if man.contact():
                man.speed = -6

            if man.is_dead():
                break
            man.update()
            update_platform()
            pygame.display.update()
            tick_time = clock.tick(FPS)
