import random
import math
import copy

network = [6, [13], 1]
population = 50  # 种群数量
elite_ratio = 0.2  # 选取精英的比率，原封不动的遗传到下一代
random_behavior = 0.1  # 产生随机行为的比率，重新随机生成的个体比率
mutation_ratio = 0.05  # 个体在遗传父母特征时，产生突变的概率


def random_weights():
    return random.random() * 2 - 1


def sigmoid(x):
    if x > 50:
        return 1.0
    elif x < -700:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


class Neuron(object):
    def __init__(self):
        self.value = 0
        self.weights = []

    def init_weights(self, weightNum):
        for i in range(weightNum):
            self.weights.append(random_weights())


class Layer(object):
    def __init__(self):
        self.neurons = []

    def init_neurons(self, neuronNum, weightNum):
        for i in range(neuronNum):
            n = Neuron()
            n.init_weights(weightNum)
            self.neurons.append(n)


class NeuronNetwork(object):
    def __init__(self):
        self.layers = []

    def init_neuron_network(self, input, hiddens, output):  # network->[4,[7],1]
        'network需要包含神经网络的层数以及每一层神经元的数量'
        pre_layer_neuron_num = 0
        # 输入层
        input_layer = Layer()
        input_layer.init_neurons(input, pre_layer_neuron_num)
        self.layers.append(input_layer)
        pre_layer_neuron_num = len(input_layer.neurons)
        # 隐藏层
        for n_num in hiddens:
            hidden_layer = Layer()
            hidden_layer.init_neurons(n_num, pre_layer_neuron_num)
            self.layers.append(hidden_layer)
            pre_layer_neuron_num = len(hidden_layer.neurons)
        # 输出层
        output_layer = Layer()
        output_layer.init_neurons(output, pre_layer_neuron_num)
        self.layers.append(output_layer)

    def feed_value(self, inputs):
        # 初始化输入层的数据
        for i in range(len(inputs)):
            self.layers[0].neurons[i].value = inputs[i]
        pre_layer = self.layers[0]
        for layer in self.layers:  # 遍历层
            if layer == self.layers[0]:
                continue
            for neuron in layer.neurons:  # 遍历当前层的所有神经元
                sum = 0
                for i in range(len(pre_layer.neurons)):  # 遍历当前神经元的每一个权值
                    sum += neuron.weights[i] * pre_layer.neurons[i].value
                neuron.value = sigmoid(sum)
            pre_layer = layer
        result = []
        for neuron in self.layers[-1].neurons:
            result.append(neuron.value)
        return result

    def get_genome_data(self):
        data = {'network': [], 'weights': []}
        for layer in self.layers:
            data['network'].append(len(layer.neurons))
            if layer == self.layers[0]:
                continue
            for neuron in layer.neurons:
                for weight in neuron.weights:
                    data['weights'].append(weight)
        return data

    def set_genome_data(self, data):
        self.layers = []
        pre_layer_n_num = 0
        date_weight_index = 0
        for n_num in data['network']:
            layer = Layer()
            layer.init_neurons(n_num, pre_layer_n_num)
            for neuron in layer.neurons:
                for i in range(len(neuron.weights)):
                    neuron.weights[i] = data['weights'][date_weight_index]
                    date_weight_index += 1
            self.layers.append(layer)
            pre_layer_n_num = n_num


class Genome(object):
    def __init__(self, genome_data, score):
        # data要能够全面描述个体的神经网络
        self.data = genome_data
        # 可以描述基因优劣程度的数据
        self.score = score

    # class Individual(object):
    #     pass


class Generation(object):
    def __init__(self):
        self.genomes = []

    def insert_genome(self, genome):
        i = 0
        for g in self.genomes:
            if genome.score > g.score:
                break
            i += 1
        self.genomes.insert(i, genome)

    def create_next_generation_data_list(self):
        next_data_list = []
        # 1.精英原封不动的遗传
        for i in range(round(population * elite_ratio)):
            next_data_list.append(self.genomes[i].data)
        # 2.有一定比率的随机个体
        for i in range(round(population * random_behavior)):
            new_network = NeuronNetwork()
            new_network.init_neuron_network(network[0], network[1], network[2])
            next_data_list.append(new_network.get_genome_data())
        # 3.选取2个个体进行繁殖
        while True:
            father = self.genomes[0]
            mother = self.genomes[1]
            if father == mother:
                continue
            child = self.breed(father.data, mother.data)
            next_data_list.append(child)
            if len(next_data_list) == population:
                break
        return next_data_list

    def breed(self, father, mother):
        child = copy.deepcopy(father)
        # 交叉
        for i in range(len(mother['weights'])):
            if random.random() < 0.5:
                child['weights'][i] = mother['weights'][i]
        # 突变
        for i in range(len(child['weights'])):
            if random.random() < mutation_ratio:
                child['weights'][i] = random_weights()
        return child


class GenerationManager(object):
    def __init__(self):
        self.generations = []

    def create_first_generation(self):
        data_list = []
        for i in range(population):
            new_network = NeuronNetwork()
            new_network.init_neuron_network(network[0], network[1], network[2])
            new_date = new_network.get_genome_data()
            data_list.append(new_date)
        self.generations.append(Generation())
        return data_list

    def create_next_generation(self):
        data_list = self.generations[-1].create_next_generation_data_list()
        self.generations.append(Generation())
        return data_list

    def add_genome(self, genome):
        if len(self.generations) > 0:
            self.generations[-1].insert_genome(genome)


class AI(object):
    def __init__(self):
        self.manager = GenerationManager()

    def next_generation(self):  # 前面的都是创建data，这里需要返回神经网络列表
        nework_list = []
        if len(self.manager.generations) > 0:
            data_list = self.manager.create_next_generation()
        else:
            data_list = self.manager.create_first_generation()
        for data in data_list:
            new_network = NeuronNetwork()
            new_network.set_genome_data(data)
            nework_list.append(new_network)
        if len(self.manager.generations) > 1:
            del self.manager.generations[0:len(self.manager.generations) - 1]
        return nework_list

    def gather_score(self, network, score):
        self.manager.add_genome(Genome(network.get_genome_data(), score))
