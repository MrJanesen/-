import pygame
import pygame.locals as locals
import random
import neuro_evolution


class Man(object):
    speed = 0

    def __init__(self, neuro_network):
        self.img = pygame.image.load("./picture/peiqi.png")
        self.width = self.img.get_width()
        self.height = self.img.get_height()
        self.x = SCREEN_SIZE[0] / 2 - self.width / 2
        self.y = self.height / 2
        self.max_speed = 5
        self.neuro_network = neuro_network
        self.alive = True

    def get_inputs(self, platform_list):
        inputs = [self.y, self.x, 0, 0, 0,0]
        for platform in platform_list:
            if self.y < platform.y + Platform.HEIGHT:
                inputs[2] = self.x + self.width / 4 * 3 - platform.x
                inputs[3] = self.x + self.width / 4 - platform.x - platform.WIDTH
                inputs[4] = SCREEN_SIZE[0]-self.x
                inputs[5] = self.y + self.height - platform.y - platform.HEIGHT
        return inputs

    def update(self, surface):
        if self.speed < self.max_speed:
            self.speed += 1
        self.y += self.speed
        surface.blit(self.img, (self.x, self.y))

    def left_move(self):
        self.x -= self.width / 2

    def right_move(self):
        self.x += self.width / 2

    def is_dead(self):
        if self.y <= 0 or self.y > (SCREEN_SIZE[1] - self.height) or self.x ==0 or self.x+self.width == SCREEN_SIZE[0]:
            self.alive = False
            return True
        return False

    def contact(self, platform_list):
        for platform in platform_list:
            if self.x + self.width / 4 * 3 > platform.x and self.x + self.width / 4 < platform.x + platform.WIDTH:
                if self.y + self.height >= platform.y and self.y + self.height <= platform.y + platform.HEIGHT:
                    self.speed = -6
                    return True
        return False


class Platform(object):
    img = pygame.image.load("./picture/platform.png")
    WIDTH = img.get_width()
    HEIGHT = img.get_height()
    speed = 4
    def __init__(self):
        self.y = SCREEN_SIZE[1]
        self.x = random.randint(0, SCREEN_SIZE[0] - Platform.WIDTH)

    def update(self, surface):
        self.y -= self.speed
        surface.blit(Platform.img, (self.x, self.y))

    def need_remove(self):
        if self.y == 0:
            return True
        return False


class Game(object):
    def __init__(self):
        self.surface = pygame.display.set_mode(SCREEN_SIZE)
        self.clock = pygame.time.Clock()
        self.ai = neuro_evolution.AI()

    def init(self):
        self.man_list = []
        network_list = self.ai.next_generation()
        for network in network_list:
            self.man_list.append(Man(network))
        self.platform_list = []
        self.platform_list.append(Platform())
        self.distance = 0

    def run(self):
        while True:
            self.distance += 1
            self.controller()
            self.surface.fill((152, 199, 252))
            if self.is_all_dead():
                self.init()
                continue
            self.update_platforms()
            self.update_men()
            pygame.display.update()
            print("存活：" + str(len(self.man_list)) + ",分数：" + str(self.distance))
            if self.distance > 50000:
                # 保存模型
                break
            self.clock.tick(FPS)

    def is_all_dead(self):
        for man in self.man_list:
            if not man.is_dead():
                return False
        return True

    def controller(self):
        for event in pygame.event.get():
            if event.type == locals.QUIT:
                exit()
            # if event.type == VIDEORESIZE:
            #     SCREEN_SIZE = event.size

    def create_platform(self):
        if self.distance % 50 == 0:
            self.platform_list.append(Platform())

    def update_platforms(self):
        self.create_platform()
        i = len(self.platform_list) - 1
        while i >= 0:
            if not self.platform_list[i].need_remove():
                self.platform_list[i].update(self.surface)
            else:
                del self.platform_list[i]
            i -= 1

    def update_men(self):
        i = len(self.man_list) - 1
        while i >= 0:
            if not self.man_list[i].is_dead():
                if self.man_list[i].contact(self.platform_list):
                    self.man_list[i].speed=-6
                inputs = self.man_list[i].get_inputs(self.platform_list)
                ret = self.man_list[i].neuro_network.feed_value(inputs)
                if ret[0] > 0.5:
                    self.man_list[i].left_move()
                elif ret[0] < 0.5:
                    self.man_list[i].right_move()
                self.man_list[i].update(self.surface)
            else:
                self.ai.gather_score(self.man_list[i].neuro_network, self.distance)
                del self.man_list[i]
            i -= 1


pygame.init()
FPS = 50
SCREEN_SIZE = (350, 480)

if __name__ == '__main__':
    game = Game()
    game.init()
    game.run()
